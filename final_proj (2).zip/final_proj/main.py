# Unified 3-Link Robot Simulator - Advanced Excel Data Logger Edition
import os
import sys
import numpy as np
import random
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from matplotlib.patches import Polygon
import pandas as pd
import warnings
warnings.filterwarnings("ignore", category=UserWarning)

# Global parameters
L1, L2, L3 = 0.0, 0.0, 0.0
MAX_REACH = 0.0

# Joint Limit Arrays (Radians)
JOINT_MIN = np.zeros(3)
JOINT_MAX = np.zeros(3)

# Global variables for path tracking and directory structures
RUN_DIR = ""
PART_COUNTER = 1


# ==================== Kinematics Core ====================

def forward_kinematics(q):
    """Calculates the (x, y) position of the end-effector given joint angles."""
    t1, t2, t3 = q
    x = L1 * np.cos(t1) + L2 * np.cos(t1 + t2) + L3 * np.cos(t1 + t2 + t3)
    y = L1 * np.sin(t1) + L2 * np.sin(t1 + t2) + L3 * np.sin(t1 + t2 + t3)
    return np.array([x, y])


def get_all_joint_positions(q):
    """Computes the Cartesian coordinates for all robot joints."""
    t1, t2, t3 = q
    p0 = np.array([0.0, 0.0])
    p1 = p0 + L1 * np.array([np.cos(t1), np.sin(t1)])
    p2 = p1 + L2 * np.array([np.cos(t1 + t2), np.sin(t1 + t2)])
    p3 = p2 + L3 * np.array([np.cos(t1 + t2 + t3), np.sin(t1 + t2 + t3)])
    return p1, p2, p3


def jacobian(q):
    """Calculates the 2x3 Jacobian matrix for the 3-link planar robot."""
    t1, t2, t3 = q
    s1, c1 = np.sin(t1), np.cos(t1)
    s12, c12 = np.sin(t1 + t2), np.cos(t1 + t2)
    s123, c123 = np.sin(t1 + t2 + t3), np.cos(t1 + t2 + t3)
    return np.array([
        [-L1 * s1 - L2 * s12 - L3 * s123, -L2 * s12 - L3 * s123, -L3 * s123],
        [L1 * c1 + L2 * c12 + L3 * c123, L2 * c12 + L3 * c123, L3 * c123]
    ])


def pseudo_inverse(J, damping=0.03):
    """Damped Least Squares Pseudo-inverse for handling singularities cleanly."""
    return J.T @ np.linalg.inv(J @ J.T + damping * np.eye(2))


def inverse_kinematics_position(target, q_guess=None, max_iter=250):
    """Robust Numerical IK solver using Damped Newton-Raphson."""
    guesses = []
    if q_guess is not None:
        guesses.append(q_guess.copy())
    
    q_center = (JOINT_MIN + JOINT_MAX) / 2.0
    guesses.append(q_center.copy())
    
    np.random.seed(42)  
    for _ in range(40):
        guesses.append(np.random.uniform(JOINT_MIN, JOINT_MAX))
        
    for guess in guesses:
        q = guess.copy()
        converged = False
        for _ in range(max_iter):
            pos = forward_kinematics(q)
            err = target - pos
            if np.linalg.norm(err) < 1e-4:
                converged = True
                break
            J = jacobian(q)
            J_pinv = J.T @ np.linalg.inv(J @ J.T + 1e-4 * np.eye(2))
            dq = J_pinv @ err
            max_step = 0.25
            if np.linalg.norm(dq) > max_step:
                dq = (dq / np.linalg.norm(dq)) * max_step
            q += dq
            q = q_center + np.arctan2(np.sin(q - q_center), np.cos(q - q_center))
            
        if converged:
            if np.all(q >= JOINT_MIN - 1e-2) and np.all(q <= JOINT_MAX + 1e-2):
                return np.clip(q, JOINT_MIN, JOINT_MAX)
    return None


def find_alternative_branch(target, current_q):
    """Guarantees finding the flipped elbow configuration for the arm swap effect."""
    q_center = (JOINT_MIN + JOINT_MAX) / 2.0
    q_flip = current_q.copy()
    q_flip[1] = -q_flip[1]
    q_flip[2] = -q_flip[2]
    
    q = q_flip.copy()
    for _ in range(60):
        pos = forward_kinematics(q)
        err = target - pos
        if np.linalg.norm(err) < 1e-4:
            if np.all(q >= JOINT_MIN) and np.all(q <= JOINT_MAX):
                if np.linalg.norm(q - current_q) > 0.4:
                    return q
        J = jacobian(q)
        J_pinv = J.T @ np.linalg.inv(J @ J.T + 1e-4 * np.eye(2))
        q += J_pinv @ err
        q = q_center + np.arctan2(np.sin(q - q_center), np.cos(q - q_center))
        
    np.random.seed(99)
    for _ in range(100):
        guess = np.random.uniform(JOINT_MIN, JOINT_MAX)
        q = guess.copy()
        for _ in range(100):
            pos = forward_kinematics(q)
            err = target - pos
            if np.linalg.norm(err) < 1e-4:
                if np.all(q >= JOINT_MIN) and np.all(q <= JOINT_MAX) and np.linalg.norm(q - current_q) > 0.5:
                    return q
            J = jacobian(q)
            J_pinv = J.T @ np.linalg.inv(J @ J.T + 1e-4 * np.eye(2))
            q += J_pinv @ err
            q = q_center + np.arctan2(np.sin(q - q_center), np.cos(q - q_center))
            
    return None


def inverse_velocity_control(q, desired_vel, dt):
    """Velocity control loop utilizing buffer zones for limit avoidance."""
    J = jacobian(q)
    J_pinv = pseudo_inverse(J, damping=0.03)
    dq_task = J_pinv @ desired_vel
    
    dq_null = np.zeros(3)
    for i in range(3):
        joint_range = JOINT_MAX[i] - JOINT_MIN[i]
        upper_buffer = JOINT_MAX[i] - 0.05 * joint_range
        lower_buffer = JOINT_MIN[i] + 0.05 * joint_range
        if q[i] > upper_buffer:
            dq_null[i] = -2.0 * (q[i] - upper_buffer)
        elif q[i] < lower_buffer:
            dq_null[i] = -2.0 * (q[i] - lower_buffer)
            
    I = np.eye(3)
    dq = dq_task + (I - J_pinv @ J) @ dq_null
    q_next = np.clip(q + dq * dt, JOINT_MIN, JOINT_MAX)
    return q_next, (q_next - q) / dt


def check_reachability(point):
    """Validates if target is physically within the usable workspace envelope."""
    return np.linalg.norm(point) <= (MAX_REACH - 0.02)


def check_trajectory_feasibility(mode_type, q_init, params, speed, dt=0.02):
    """Simulates the complete path in the background to verify tracking safety."""
    print("\n🔄 Evaluating digital twin look-ahead and path feasibility...")
    q_test = q_init.copy()
    swapped_test = False
    
    if mode_type == 'circle':
        center, radius = params
        angular_speed = (speed * 2) / radius
        total_steps = int((2 * np.pi) / (angular_speed * dt)) + 5
        
        for step in range(total_steps):
            progress = step * angular_speed * dt
            if progress > 2 * np.pi: progress = 2 * np.pi
            angle = np.pi + progress
            desired_pos = np.array([center[0] + radius * np.cos(angle), center[1] + radius * np.sin(angle)])
            
            if not swapped_test:
                hit_limit = False
                for i in range(3):
                    jr = JOINT_MAX[i] - JOINT_MIN[i]
                    if (q_test[i] > JOINT_MAX[i] - 0.05 * jr) or (q_test[i] < JOINT_MIN[i] + 0.05 * jr):
                        hit_limit = True
                        break
                if hit_limit:
                    q_alt = find_alternative_branch(desired_pos, q_test)
                    if q_alt is not None:
                        q_test = q_alt
                        swapped_test = True
                        
            ee_pos = forward_kinematics(q_test)
            error = desired_pos - ee_pos
            v_des = error / dt
            q_next, _ = inverse_velocity_control(q_test, v_des, dt)
            ee_pos_next = forward_kinematics(q_next)
            
            if np.linalg.norm(ee_pos_next - desired_pos) > 0.08:
                print(f"❌ Path Deviation Error: High tracking error predicted near: ({desired_pos[0]:.2f}, {desired_pos[1]:.2f})")
                return False
            q_test = q_next
            
    elif mode_type == 'auto':
        start, target = params
        total_dist = np.linalg.norm(target - start)
        if total_dist < 1e-5: return True
        
        sim_speed = 2.0 * speed
        t = 0.0
        while t < 1.0:
            ds = sim_speed * dt / total_dist
            t += ds
            if t > 1.0: t = 1.0
            
            desired_pos = start + t * (target - start)
            
            if not swapped_test:
                hit_limit = False
                for i in range(3):
                    jr = JOINT_MAX[i] - JOINT_MIN[i]
                    if (q_test[i] > JOINT_MAX[i] - 0.05 * jr) or (q_test[i] < JOINT_MIN[i] + 0.05 * jr):
                        hit_limit = True
                        break
                if hit_limit:
                    q_alt = find_alternative_branch(desired_pos, q_test)
                    if q_alt is not None:
                        q_test = q_alt
                        swapped_test = True
                        
            ee_pos = forward_kinematics(q_test)
            error = desired_pos - ee_pos
            v_des = (error / dt) if np.linalg.norm(error) > 0 else np.zeros(2)
            if np.linalg.norm(v_des) > sim_speed:
                v_des = v_des / np.linalg.norm(v_des) * sim_speed
                
            q_test, _ = inverse_velocity_control(q_test, v_des, dt)
            ee_pos_next = forward_kinematics(q_test)
            
            if np.linalg.norm(desired_pos - ee_pos_next) > 0.08:
                print(f"❌ Path Deviation Error: Limit restriction locked movement near: ({desired_pos[0]:.2f}, {desired_pos[1]:.2f})")
                return False
                
    print("✅ Path verified as safe and fully reachable.")
    return True


# ==================== Directory Management Handler ====================

def initialize_run_directory():
    """Finds the last run folder number and creates a new unique run folder."""
    global RUN_DIR
    parent_folder = "run_results"
    
    if not os.path.exists(parent_folder):
        os.makedirs(parent_folder)
        
    existing_runs = [d for d in os.listdir(parent_folder) if d.startswith("run_") and d[4:].isdigit()]
    
    if not existing_runs:
        next_run_number = 1
    else:
        run_numbers = [int(d.split("_")[1]) for d in existing_runs]
        next_run_number = max(run_numbers) + 1
        
    RUN_DIR = os.path.join(parent_folder, f"run_{next_run_number}")
    os.makedirs(RUN_DIR)
    print(f"\n📂 Setup completed. All excel parts will save under directory: {RUN_DIR}")

def cleanup_empty_run_directory():
    """Checks if the current RUN_DIR is empty; if so, deletes it to clean up."""
    global RUN_DIR
    if RUN_DIR and os.path.exists(RUN_DIR):
        # check file is emty
        if not os.listdir(RUN_DIR):
            try:
                os.rmdir(RUN_DIR)
                print(f"\n🧹 Cleaned up empty directory: {RUN_DIR}")
            except Exception as e:
                print(f"\n⚠️ Could not remove empty directory: {e}")


# ==================== Unified Simulator Engine ====================

class RobotSimulator:
    def __init__(self, mode, speed, initial_q, start_pt=None, target_pt=None, center=None, radius=None, previous_paths=None):
        self.mode = mode  # 'auto', 'manual', 'circle'
        self.speed = float(speed) * 2.0
        self.q = initial_q.copy()
        self.ee_pos = forward_kinematics(self.q)
        self.dt = 0.02
        self.finished = False
        self.swapped = False
        self.dq = np.zeros(3)
        self.previous_paths = previous_paths if previous_paths is not None else []
        
        # Data logger arrays
        self.time_history = []
        self.data_records = []
        self.frame_count = 0
        self.elapsed_time = 0.0

        # Mode-specific trajectory attributes
        self.start = np.array(start_pt) if start_pt is not None else self.ee_pos.copy()
        self.target = np.array(target_pt) if target_pt is not None else self.ee_pos.copy()
        self.last_ee_pos = self.ee_pos.copy()
        self.t_linear = 0.0
        
        self.center = np.array(center) if center is not None else np.zeros(2)
        self.radius = float(radius) if radius is not None else 0.0
        self.progress_circle = 0.0
        if self.radius > 0:
            self.angular_speed = self.speed / self.radius

        # Graphic setup
        self.fig, (self.ax, self.ax_info) = plt.subplots(1, 2, figsize=(12, 7), gridspec_kw={'width_ratios': [3, 1.2]})
        self.setup_static_background()
        self.setup_moving_artists()
        self.setup_info_panel()

    def setup_static_background(self):
        self.ax.set_xlim(-MAX_REACH - 1, MAX_REACH + 1)
        self.ax.set_ylim(-MAX_REACH - 1, MAX_REACH + 1)
        self.ax.set_aspect('equal')
        self.ax.grid(True, linestyle='--', alpha=0.3, color='#999999')
        self.ax.set_facecolor('#F8F9FA')
        self.ax.set_title(f"3-Link Robot Simulator - [{self.mode.upper()} MODE]", fontsize=11, fontweight='bold', color='#212529')
        self.ax.plot(0, 0, 'ms', markersize=12, color='#343A40', zorder=5, label='Robot Base')

        for (p1, p2) in self.previous_paths:
            self.ax.plot([p1[0], p2[0]], [p1[1], p2[1]], 'k--', lw=1.5, alpha=0.5)

        if self.mode == 'circle':
            circle_contour = plt.Circle(self.center, self.radius, color='#DC3545', fill=False, linestyle='--', linewidth=1.8, label='Target Circle')
            self.ax.add_patch(circle_contour)
        elif self.mode == 'auto':
            self.ax.plot([self.start[0], self.target[0]], [self.start[1], self.target[1]], 'r--', lw=1.8, alpha=0.8, label='Linear Path')
            self.ax.plot(self.start[0], self.start[1], 'b*', markersize=10, label='Start')
            self.ax.plot(self.target[0], self.target[1], 'r*', markersize=10, label='Target')

        self.ax.legend(loc='upper right', fontsize=9)

    def setup_moving_artists(self):
        self.link_colors = ['#495057', '#6C757D', '#FD7E14']
        self.link_patches = [Polygon(np.zeros((4, 2)), closed=True, color=self.link_colors[i], zorder=3) for i in range(3)]
        for patch in self.link_patches:
            self.ax.add_patch(patch)

        self.joints = [self.ax.plot([], [], 'o', color='#212529', markeredgecolor='#E9ECEF', markeredgewidth=1.5, markersize=10, zorder=4)[0] for _ in range(3)]
        
        self.gripper_base, = self.ax.plot([], [], color='#343A40', linewidth=4, solid_capstyle='round', zorder=4)
        self.gripper_left, = self.ax.plot([], [], color='#212529', linewidth=3, solid_capstyle='round', zorder=4)
        self.gripper_right, = self.ax.plot([], [], color='#212529', linewidth=3, solid_capstyle='round', zorder=4)

        self.trace_x, self.trace_y = [], []
        self.trail_line, = self.ax.plot([], [], color='#28A745', linestyle='-', lw=2, alpha=0.8, label='EE Trace')

    def setup_info_panel(self):
        self.ax_info.axis('off')
        self.ax_info.set_xlim(0, 1)
        self.ax_info.set_ylim(0, 1)
        self.texts = {}
        y_pos = 0.8
        labels = ["θ1 (deg):", "θ2 (deg):", "θ3 (deg):", "Status:"]
        for label in labels:
            self.texts[label] = self.ax_info.text(0.05, y_pos, f"{label} 0.0", fontsize=10, verticalalignment='center', fontfamily='sans-serif')
            y_pos -= 0.15
        self.texts["Status:"].set_text("Status: Initialized")

    def execute_configuration_flip(self, desired_pos):
        """Monitors buffers and triggers a rapid structural IK branch switch if required."""
        if not self.swapped:
            hit_limit = False
            for i in range(3):
                joint_range = JOINT_MAX[i] - JOINT_MIN[i]
                if (self.q[i] > JOINT_MAX[i] - 0.05 * joint_range) or (self.q[i] < JOINT_MIN[i] + 0.05 * joint_range):
                    hit_limit = True
                    break
            
            if hit_limit:
                q_alt = find_alternative_branch(desired_pos, self.q)
                if q_alt is not None:
                    self.q = q_alt
                    self.swapped = True
                    self.texts["Status:"].set_text("Status: AUTO FLIPPED")
                    self.texts["Status:"].set_color('#D63384')

    def log_telemetry_data(self):
        """Samples state parameters precisely every 0.2 seconds (10 execution loops)."""
        if self.frame_count % 10 == 0:
            p1, p2, p3 = get_all_joint_positions(self.q)
            
            record = {
                "Time (s)": round(self.elapsed_time, 2),
                "Vel_Joint1 (rad/s)": self.dq[0],
                "Vel_Joint2 (rad/s)": self.dq[1],
                "Vel_Joint3 (rad/s)": self.dq[2],
                "Angle_Joint1 (deg)": np.degrees(self.q[0]),  # تبدیل به درجه
                "Angle_Joint2 (deg)": np.degrees(self.q[1]),  # تبدیل به درجه
                "Angle_Joint3 (deg)": np.degrees(self.q[2]),  # تبدیل به درجه
                "Joint1_X": p1[0], "Joint1_Y": p1[1],
                "Joint2_X": p2[0], "Joint2_Y": p2[1],
                "Joint3_X": p3[0], "Joint3_Y": p3[1]
            }
            self.data_records.append(record)

    def save_to_excel(self):
        """Compiles recorded states and exports them to an Excel file spreadsheet."""
        global PART_COUNTER
        if not self.data_records:
            return
            
        df = pd.DataFrame(self.data_records)
        df.set_index("Time (s)", inplace=True)
        
        file_path = os.path.join(RUN_DIR, f"part_{PART_COUNTER}.xlsx")
        df.to_excel(file_path)
        print(f"📊 Spreadsheet saved successfully: {file_path}")
        PART_COUNTER += 1

    def update(self, frame):
        self.elapsed_time = self.frame_count * self.dt
        
        if not self.finished and self.mode != 'manual':
            if self.mode == 'circle':
                self.progress_circle += self.angular_speed * self.dt
                if self.progress_circle >= 2 * np.pi:
                    self.progress_circle = 2 * np.pi
                    self.finished = True
                angle = np.pi + self.progress_circle
                desired_pos = np.array([self.center[0] + self.radius * np.cos(angle), self.center[1] + self.radius * np.sin(angle)])
            else: 
                total_dist = np.linalg.norm(self.target - self.start)
                if total_dist < 1e-5:
                    self.finished = True
                    desired_pos = self.target.copy()
                else:
                    self.t_linear += self.speed * self.dt / total_dist
                    if self.t_linear >= 1.0:
                        self.t_linear = 1.0
                        self.finished = True
                    desired_pos = self.start + self.t_linear * (self.target - self.start)

            self.execute_configuration_flip(desired_pos)

            error = desired_pos - self.ee_pos
            v_des = error / self.dt
            if self.mode == 'auto' and np.linalg.norm(v_des) > self.speed:
                v_des = v_des / np.linalg.norm(v_des) * self.speed
                
            self.q, self.dq = inverse_velocity_control(self.q, v_des, self.dt)
            self.ee_pos = forward_kinematics(self.q)
            
            # Record current step trajectory parameters
            self.log_telemetry_data()

            self.trace_x.append(self.ee_pos[0])
            self.trace_y.append(self.ee_pos[1])
            self.trail_line.set_data(self.trace_x, self.trace_y)

            if self.finished:
                self.texts["Status:"].set_text("Status: Finished")
                self.texts["Status:"].set_color('black')
                self.save_to_excel()
            elif not self.swapped:
                self.texts["Status:"].set_text("Status: Tracking Path")
                self.texts["Status:"].set_color('black')

        elif self.mode == 'manual':
            self.log_telemetry_data()

        # Render Robot Links & Gripper Shape
        t1, t2, t3 = self.q
        p0 = np.array([0., 0.])
        p1 = p0 + L1 * np.array([np.cos(t1), np.sin(t1)])
        p2 = p1 + L2 * np.array([np.cos(t1 + t2), np.sin(t1 + t2)])
        p3 = p2 + L3 * np.array([np.cos(t1 + t2 + t3), np.sin(t1 + t2 + t3)])
        points = [p0, p1, p2, p3]

        base_width = MAX_REACH * 0.024
        widths = [base_width, base_width * 0.75, base_width * 0.50]
        angles = [t1, t1 + t2, t1 + t2 + t3]

        for i in range(3):
            start = points[i]
            ang = angles[i]
            w_start = widths[i]
            w_end = widths[i] * 0.65
            perp = np.array([-np.sin(ang), np.cos(ang)])
            v0 = start + perp * (w_start / 2)
            v1 = start - perp * (w_start / 2)
            v2 = points[i+1] - perp * (w_end / 2)
            v3 = points[i+1] + perp * (w_end / 2)
            self.link_patches[i].set_xy(np.array([v0, v1, v2, v3]))

        for i in range(3):
            self.joints[i].set_data([points[i][0]], [points[i][1]])

        global_tool_angle = t1 + t2 + t3
        cos_g, sin_g = np.cos(global_tool_angle), np.sin(global_tool_angle)
        gripper_normal = np.array([-sin_g, cos_g])
        gripper_extend = np.array([cos_g, sin_g])
        
        crossbar_half_width = MAX_REACH * 0.024
        finger_length = MAX_REACH * 0.032
        finger_offset = MAX_REACH * 0.005
        
        g_left = p3 + gripper_normal * crossbar_half_width
        g_right = p3 - gripper_normal * crossbar_half_width
        g_left_tip = g_left + gripper_extend * finger_length - gripper_normal * finger_offset
        g_right_tip = g_right + gripper_extend * finger_length + gripper_normal * finger_offset

        self.gripper_base.set_data([g_left[0], g_right[0]], [g_left[1], g_right[1]])
        self.gripper_left.set_data([g_left[0], g_left_tip[0]], [g_left[1], g_left_tip[1]])
        self.gripper_right.set_data([g_right[0], g_right_tip[0]], [g_right[1], g_right_tip[1]])

        self.texts["θ1 (deg):"].set_text(f"θ1 (deg): {np.degrees(self.q[0]):.1f}")
        self.texts["θ2 (deg):"].set_text(f"θ2 (deg): {np.degrees(self.q[1]):.1f}")
        self.texts["θ3 (deg):"].set_text(f"θ3 (deg): {np.degrees(self.q[2]):.1f}")

        self.frame_count += 1
        artists = self.link_patches + self.joints + [self.gripper_base, self.gripper_left, self.gripper_right, self.trail_line] + list(self.texts.values())
        return artists

    def move_manual(self, direction_key):
        if self.mode != 'manual': return
        step = (self.speed * 0.02)
        delta = np.zeros(2)
        if direction_key == 'up': delta = np.array([0, step])
        elif direction_key == 'down': delta = np.array([0, -step])
        elif direction_key == 'left': delta = np.array([-step, 0])
        elif direction_key == 'right': delta = np.array([step, 0])

        new_pos = self.ee_pos + delta
        if not check_reachability(new_pos):
            print("⚠️ Position outside reachable workspace boundary!")
            return

        self.execute_configuration_flip(new_pos)
        q_possible = inverse_kinematics_position(new_pos, q_guess=self.q)
        if q_possible is None:
            print("⚠️ Limit Violation: Flipped or regular configurations cannot reach this coordinate.")
            return

        self.ax.plot([self.last_ee_pos[0], new_pos[0]], [self.last_ee_pos[1], new_pos[1]], 'k--', lw=1.5, alpha=0.5)
        self.previous_paths.append((self.last_ee_pos.copy(), new_pos.copy()))
        
        self.last_ee_pos = new_pos.copy()
        self.q = q_possible
        self.ee_pos = forward_kinematics(self.q)
        self.fig.canvas.draw_idle()

    def on_key_press(self, event):
        if event.key in ['up', 'down', 'left', 'right']:
            self.move_manual(event.key)

    def run(self):
        if self.mode == 'manual':
            self.fig.canvas.mpl_connect('key_press_event', self.on_key_press)
            ani = FuncAnimation(self.fig, self.update, interval=self.dt * 1000, blit=False, cache_frame_data=False)
        else:
            ani = FuncAnimation(self.fig, self.update, interval=self.dt * 1000, blit=True, cache_frame_data=False)
        plt.tight_layout()
        plt.show()
        
        # Ensures manual or prematurely closed charts save whatever telemetry they gathered
        if self.mode == 'manual' or not self.finished:
            self.save_to_excel()


# ==================== Runtime Entry Point ====================

if __name__ == "__main__":
    try:
        print("=" * 60)
        print("Unified 3-Link Robot Simulator - Predictive Workspace Edition")
        print("=" * 60)

        L1 = float(input("Link L1 length: "))
        L2 = float(input("Link L2 length: "))
        L3 = float(input("Link L3 length: "))
        MAX_REACH = L1 + L2 + L3

        print("\n--- Enter Joint Angle Limits (in Degrees) ---")
        for i in range(3):
            JOINT_MIN[i] = np.radians(float(input(f"Joint {i+1} MIN angle: ")))
            JOINT_MAX[i] = np.radians(float(input(f"Joint {i+1} MAX angle: ")))

        # Initialize the global folder structure for logging
        initialize_run_directory()

        print("\nSelect execution mode:")
        print("1 = Automatic Linear Path")
        print("2 = Manual Keyboard Control")
        print("3 = Circular Trajectory Control")
        mode_selection = input("Choose mode (1/2/3): ").strip()

        if mode_selection == '2':
            speed = float(input("Enter operational speed scale (1.0 to 5.0): "))
            print("\nSearching for a valid random start point...")
            while True:
                rx = random.uniform(-MAX_REACH + 0.5, MAX_REACH - 0.5)
                ry = random.uniform(-MAX_REACH + 0.5, MAX_REACH - 0.5)
                if check_reachability((rx, ry)):
                    q_init = inverse_kinematics_position((rx, ry))
                    if q_init is not None:
                        break
            print(f"Robot starting at valid position: ({rx:.2f}, {ry:.2f})")
            print("Use Arrow Keys on the popup window to guide the industrial gripper.")
            sim = RobotSimulator(mode='manual', speed=speed, initial_q=q_init)
            sim.run()

        elif mode_selection == '3':
            cx = float(input("Circle Center X: "))
            cy = float(input("Circle Center Y: "))
            radius = float(input("Circle Radius R: "))
            speed = float(input("Tangential Speed (1.0 to 5.0): "))

            start_x = cx - radius
            start_y = cy
            q_start = inverse_kinematics_position((start_x, start_y))

            if q_start is None:
                print("❌ Error: Circle starting point is structurally unreachable inside joint configurations!")
                sys.exit()

            is_safe = check_trajectory_feasibility('circle', q_start, (np.array([cx, cy]), radius), speed)
            if not is_safe:
                print("\n🛑 Simulation aborted due to upcoming tracking workspace failures!")
                sys.exit()

            sim = RobotSimulator(mode='circle', speed=speed, initial_q=q_start, center=(cx, cy), radius=radius)
            sim.run()

            current_q = sim.q  
            
            while True:
                print("\n" + "=" * 50)
                print("Configure a new Circle Trajectory")
                cx_in = input("Next Circle Center X (or press 'C' to terminate loop): ").strip()
                if cx_in.upper() == 'C':
                    print("Exiting Simulator framework.")
                    break
                try:
                    cx_next = float(cx_in)
                    cy_next = float(input("Next Circle Center Y: "))
                    radius_next = float(input("Next Circle Radius R: "))
                    speed = float(input("Tangential Speed (1.0 to 5.0): "))
                    
                    start_x_next = cx_next - radius_next
                    start_y_next = cy_next
                    
                    q_start_next = inverse_kinematics_position((start_x_next, start_y_next), q_guess=current_q)
                    if q_start_next is None:
                        print("⚠️ The starting point of the new circle breaches physical limit arrays.")
                        continue
                    
                    is_safe = check_trajectory_feasibility('circle', q_start_next, (np.array([cx_next, cy_next]), radius_next), speed)
                    if not is_safe:
                        print("🛑 Execution blocked. Continuous circular trajectory is invalid.")
                        continue
                        
                    sim = RobotSimulator(mode='circle', speed=speed, initial_q=q_start_next, 
                                                center=(cx_next, cy_next), radius=radius_next)
                    sim.run()
                    current_q = sim.q  
                except ValueError:
                    print("Invalid numerical coordinate inputs.")

        else: # Automatic mode
            sx = float(input("Start point x: "))
            sy = float(input("Start point y: "))
            tx = float(input("Target point x: "))
            ty = float(input("Target point y: "))
            speed = float(input("System linear speed scale (1.0 to 5.0): "))

            q_start = inverse_kinematics_position((sx, sy))
            if q_start is None:
                print("❌ Error: Specified initial point violates system boundary limits.")
                sys.exit()
            if inverse_kinematics_position((tx, ty)) is None:
                print("❌ Error: Ultimate path target point has no mathematical joint configuration.")
                sys.exit()

            is_safe = check_trajectory_feasibility('auto', q_start, (np.array([sx, sy]), np.array([tx, ty])), speed)
            if not is_safe:
                print("\n🛑 Simulation aborted due to joint lock trajectory tracking failures!")
                sys.exit()

            sim = RobotSimulator(mode='auto', speed=speed, initial_q=q_start, start_pt=(sx, sy), target_pt=(tx, ty))
            sim.run()

            all_paths = [(sim.start, sim.target)]
            current_pos = sim.target
            current_q = sim.q
            
            while True:
                print("\n" + "=" * 50)
                print(f"Current Position Vector: ({current_pos[0]:.2f}, {current_pos[1]:.2f})")
                tx_in = input("Next target x (or press 'C' to terminate loop): ").strip()
                if tx_in.upper() == 'C':
                    print("Exiting Simulator framework.")
                    break
                try:
                    tx_next = float(tx_in)
                    ty_next = float(input("Next target y: "))
                    speed = float(input("Tangential Speed (1.0 to 5.0): "))
                    
                    if inverse_kinematics_position((tx_next, ty_next), q_guess=current_q) is None:
                        print("⚠️ Target node coordinate itself breaches physical limit arrays.")
                        continue
                    
                    is_safe = check_trajectory_feasibility('auto', current_q, (current_pos, np.array([tx_next, ty_next])), speed)
                    if not is_safe:
                        print("🛑 Execution blocked. Continuous straight navigation trajectory is invalid.")
                        continue
                        
                    sim = RobotSimulator(mode='auto', speed=speed, initial_q=current_q, 
                                                start_pt=current_pos, target_pt=(tx_next, ty_next), previous_paths=all_paths)
                    sim.run()
                    
                    all_paths.append((sim.start, sim.target))
                    current_pos = sim.target
                    current_q = sim.q
                except ValueError:
                    print("Invalid numerical coordinate inputs.")
        
    except KeyboardInterrupt:
        print("\nGoodbye!")
        sys.exit(0)
    
    finally:
        cleanup_empty_run_directory()